# Personal-Finance-PowerBI
Performed analysis to provide insights from a personal financial data


data picked from : https://github.com/codebasics/DataAnalysisProjects/tree/master/3_PersonalFinance
